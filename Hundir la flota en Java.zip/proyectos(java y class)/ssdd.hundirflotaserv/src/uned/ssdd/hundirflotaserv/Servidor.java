/**
 * Autor: Carlos Alberto Pi�ero Olanda
 * Correo electr�nico: cpinero30@alumno.uned.es
 * 
 */

package uned.ssdd.hundirflotaserv;

import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.time.LocalDateTime;
import java.util.Arrays;

import uned.ssdd.hundirflotainterfaces.*;
import uned.ssdd.hundirflotafundam.Lector;

/**
 * Esta clase contiene el m�todo main para la entidad Servidor.
 * Es una de las clases que el enunciado obliga a implementar.
 */
public class Servidor {
	/**
	 * Los �nicos campos necesarios para el m�todo main son el servicio autenticador y gestor.
	 * Aparte, vamos a registrar la fecha y hora en que se levanta el Servidor.
	 * Se mostrar� en la operaci�n de mostrar informaci�n sobre este. 
	 */
	private static ServicioGestorImpl servGes;
	private static ServicioAutenticacionImpl servAut;
	private static LocalDateTime fecha;
	
	/**
	 * El constructor va a levantar todos los objetos remotos necesarios.
	 */
	private Servidor() {
		try {
			//Se registra la fecha de creaci�n.
			fecha = LocalDateTime.now();
			
			// Primero se busca la Base de Datos.
			Registry regBBDD = LocateRegistry.getRegistry(8833);
			String nBBDD = ServicioDatosInterface.NOMBRE_DATOS;
			ServicioDatosInterface datosStub = (ServicioDatosInterface) regBBDD.lookup(nBBDD);
			
			// Se registra el servidor.
			Registry registry = LocateRegistry.createRegistry(6766);
			
			// Se levanta el autenticador.
			servAut = new ServicioAutenticacionImpl(datosStub);
			int puertoA = ServicioAutenticacionInterface.portAuten;
			ServicioAutenticacionInterface servAutStub = (ServicioAutenticacionInterface) UnicastRemoteObject.exportObject(servAut, puertoA);
			
			// Se registra el autenticador por su nombre.
			registry.rebind(ServicioAutenticacionInterface.NOMBRE_AUTEN, servAutStub);
			
			// Se levanta el gestor de partidas.
			servGes = new ServicioGestorImpl(datosStub);
			int puertoG = ServicioGestorInterface.portGestor;
			ServicioGestorInterface servGesStub = (ServicioGestorInterface) UnicastRemoteObject.exportObject(servGes, puertoG);
			
			// Se registra el gestor por su nombre.
			registry.rebind(ServicioGestorInterface.NOMBRE_GESTOR, servGesStub);
			
			// Se muestra por la consola los servicios registrados.
			System.out.println(Arrays.toString(registry.list()));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Mostrar� la interfaz del Servidor. Esta es sencilla y s�lo comprende dos operaciones m�s salir.
	 */
	public static void main(String[] args) {
		try {
			new Servidor();
			
			while (true){
				System.out.println("\nServidor operativo\nLas operaciones disponibles son:");
				System.out.println("1-Informaci�n del Servidor.");
				System.out.println("2-Estados de las partidas que se est�n disputando.\n3-Salir.");
				int opcion = Lector.leeDatosNumericos(1, 3);
				if (opcion == 3) {break;}
				else if (opcion == 2) {System.out.println(servGes.listaTodasPart());}
				else {informaServ();}
			}
			System.out.println("Servidor finalizado.");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Muestra la informaci�n del Servidor:
	 * Su fecha y hora de creaci�n, cu�ntos usuarios hay logueados y cu�ntas partidas se disputan.  
	 */
	private static void informaServ() {
		System.out.println("\nEste servidor aloja partidas on-line de Hundir la flota.");
		System.out.println("Fue creado por Carlos Alberto Pi�ero Olanda.");
		String textFecha = String.valueOf(fecha);
		String dia = textFecha.substring(0, 10);
		String hora = textFecha.substring(11, 19);
		System.out.printf("Se levant� el d�a en la fecha %s a la hora %s.", dia, hora);
		int nLog = servAut.devLog();
		int nPart = servGes.devnumP();
		System.out.printf("\nAhora mismo hay %d usuarios logueados y se est�n disputando %d partidas.\n", nLog, nPart);
	}
	
}
