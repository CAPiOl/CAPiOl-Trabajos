/**
 * Autor: Carlos Alberto Pi�ero Olanda
 * Correo electr�nico: cpinero30@alumno.uned.es
 * 
 */

package uned.ssdd.hundirflotaserv;

import java.rmi.RemoteException;
import java.util.ArrayList;

import uned.ssdd.hundirflotainterfaces.ServicioDatosInterface;
import uned.ssdd.hundirflotainterfaces.ServicioAutenticacionInterface;

/**
 * Esta clase implementa la interfaz de ServicioAutenticacionInterface.
 * Se encarga de gestionar el registro y la apertura de sesi�n de los jugadores.
 * Es una de las clases que el enunciado obliga a implementar.
 * 
 */
public class ServicioAutenticacionImpl implements ServicioAutenticacionInterface {
	/**
	 * Los campos necesarios son el servicio remoto de la Base de Datos y los jugadores logueados.
	 */
	private ServicioDatosInterface datosStub;
	private ArrayList<String> logueados;
	
	/**
	 * El constructor inicializa los campos.
	 */
	public ServicioAutenticacionImpl(ServicioDatosInterface datosStub) {
		this.datosStub = datosStub;
		this.logueados = new ArrayList<String>();
	}

	@Override
	public String registrar(String[] nombrePW) throws RemoteException {
		try {
			return datosStub.registraJug(nombrePW);
		} catch (Exception e) {
			System.err.println("Server exception: " + e.toString());
			e.printStackTrace();
		}
		return null;
	}
	
	@Override
	public String hacerLogin(String[] nombrePW) throws RemoteException {
		String nombre = nombrePW[0];
		int posLog = 0;
		for (String log : this.logueados) {
			if (log.compareTo(nombre) == 0) {return "Ya hay una sesi�n de ese jugador.";}
			else if (log.compareTo(nombre) > 0) {break;}
			else {posLog++;}
		}
		try {
			String respuesta = datosStub.existeJugador(nombrePW);
			if (respuesta.contains("Logueado")) {this.logueados.add(posLog, nombre);}
			return respuesta;
		} catch (Exception e) {
			System.err.println("Server exception: " + e.toString());
			e.printStackTrace();
		}
		return null;
	}
	
	@Override
	public String hacerUnlogin(String nombre) throws RemoteException {
		this.logueados.remove(nombre);
		return "Deslogueado";
	}
	
	/**
	 * Devuelve el n�mero de jugadores logueados.
	 * No es un m�todo remoto porque s�lo lo necesita la Base de Datos.
	 */
	protected int devLog() {return this.logueados.size();}
	
}
