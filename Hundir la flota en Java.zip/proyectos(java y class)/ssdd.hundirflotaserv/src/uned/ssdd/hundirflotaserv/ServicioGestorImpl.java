/**
 * Autor: Carlos Alberto Pi�ero Olanda
 * Correo electr�nico: cpinero30@alumno.uned.es
 * 
 */

package uned.ssdd.hundirflotaserv;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.HashMap;

import uned.ssdd.hundirflotainterfaces.ServicioDatosInterface;
import uned.ssdd.hundirflotainterfaces.ServicioGestorInterface;
import uned.ssdd.hundirflotainterfaces.CallbackJugadorInterface;
import uned.ssdd.hundirflotajuego.*;

/**
 * Esta clase implementa la interfaz de ServicioGestorInterface.
 * Se encarga de gestionar las partidas y de devolver su informaci�n.
 * Es una de las clases que el enunciado obliga a implementar.
 * 
 */
public class ServicioGestorImpl implements ServicioGestorInterface {
	/**
	 * Los campos necesarios son:
	 * 1- El servicio remoto de la Base de Datos.
	 * 2- Las partidas que se est�n disputando.
	 * 3- El n�ero de partidas disputadas para darles un identificador.
	 * 4- Los callbacks de los jugadores disputando partidas.
	 */	private ServicioDatosInterface datosStub;
	private ArrayList<Partida> partidas;
	private long numPartidas;
	private HashMap<String, CallbackJugadorInterface> callbacks;
	
	/**
	 * El constructor inicializa los campos.
	 */
	public ServicioGestorImpl(ServicioDatosInterface datosStub) {
		this.datosStub = datosStub;
		this.partidas = new ArrayList<Partida>();
		this.numPartidas = 0;
		this.callbacks = new HashMap<String, CallbackJugadorInterface>();
	}
	
	@Override
	public String informaJug(String nombre) throws RemoteException {
		try {
			return datosStub.informaJug(nombre);
		} catch (Exception e) {
			System.err.println("Server exception: " + e.toString());
			e.printStackTrace();
		}
		return null;
	}
	
	@Override
	public long creaPartida(String nJug1, CallbackJugadorInterface callback) throws RemoteException {
		this.partidas.add(new Partida(this.numPartidas, nJug1));
		this.callbacks.put(nJug1, callback);
		this.numPartidas++;
		return this.numPartidas - 1;
	}
	
	@Override
	public String[] listaPartNoInic() throws RemoteException {
		String listado = "Estas son las partidas en espera de contrincante:";
		int numPart = 0;
		for (Partida p : this.partidas) {
			if (!p.estaIniciada()) {
				listado += "\n" + p;
				numPart++;
			}
		}
		return new String[] {String.valueOf(numPart), listado + "\n"};
	}
	
	@Override
	public String[] unirsePart(String[] mensaje, CallbackJugadorInterface callback) {
		String nJug2 = mensaje[0];
		long idPart = Long.parseLong(mensaje[1]);
		for (Partida p : this.partidas) {
			if (p.coincIdent(idPart)) {
				if (!p.estaIniciada()) {
					p.uneJug(nJug2);
					this.callbacks.put(nJug2, callback);
					String respuesta = String.format("Empieza la partida entre %s y %s.", p.devJug1(), nJug2);
					respuesta += " Pod�is poner los barcos.";
					this.enviaCB(p, respuesta);
					return new String[]{"true", "��xito! Ya est�s jugando."};
				} else {return new String[]{"false", "Esta partida ya ha sido iniciada."};}
			}
		}
		return new String[]{"false", "No consta ese identificador entre las partidas no iniciadas."};
	}
	
	@Override
	public String[] leeBarcos(String[] jugada) throws RemoteException {
		long identPart = Long.parseLong(jugada[0]);
		Partida p = this.encuentraPart(identPart);
		String mensaje = p.ponBarco(new String[] {jugada[1], jugada[2]});
		if (mensaje.contains("Listo")) {
			this.enviaCB(p, "Ambos jugadores han puesto sus barcos.");
		}
		switch (mensaje) {
			case "I": return new String[] {"false", "La coordenada indicada es incorrecta."};
			case "!1", "!2": return new String[] {"false", "El barco se sale del tablero."};
			case "CB": return new String[] {"false", "Los barcos se cruzan en el tablero."};
			default: return new String[] {"true", "Tu barco se ha puesto en la posici�n adecuada."};
		}
	}
	
	@Override
	public String[] leeDisparo(String[] jugada) throws RemoteException {
		long identPart = Long.parseLong(jugada[0]);
		Partida p = this.encuentraPart(identPart);
		String[] envios = p.devMensajes(jugada[2]);
		if (Boolean.parseBoolean(envios[0])) {this.enviaCB(p, envios[1]);}
		return envios;
	}
	
	@Override
	public String[] devMensajes(String[] datos) {
		long identPart = Long.parseLong(datos[0]);
		Partida p = this.encuentraPart(identPart);
		String[] estado = p.devEstado(datos[1]);
		return estado;
	}
	

	@Override
	public void acabaPartida(String[] datos) throws RemoteException {
		this.callbacks.remove(datos[1]);
		Partida p = this.encuentraPart(Long.parseLong(datos[0]));
		if (!this.callbacks.containsKey(p.devJug1()) && !this.callbacks.containsKey(p.devJug2())) {
			try {this.datosStub.actualDatos(p.devFinal());}
			catch (Exception e) {
				System.err.println("Server exception: " + e.toString());
				e.printStackTrace();
			}
			this.partidas.remove(p);
		}
	}
	
	/**
	 * Busca la Partida a la que corresponde el identificador pasado como argumento.
	 */
	private Partida encuentraPart(long identPart) {
		for (Partida p : this.partidas) {if (p.coincIdent(identPart)) {return p;}}
		return null;
	}
	
	/**
	 * Invoca el callback de los dos jugadores de una partida.
	 */
	private void enviaCB(Partida part, String evento) {
		try {
			this.callbacks.get(part.devJug1()).recogeEvento(evento);
			this.callbacks.get(part.devJug2()).recogeEvento(evento);
		} catch (Exception e) {
			System.err.println("Server exception: " + e.toString());
			e.printStackTrace();
		} 
	}
	
	/**
	 * Devuelve el n�mero de partidas que se est�n disputando.
	 * No es un m�todo remoto porque s�lo lo necesita la Base de Datos.
	 */
	protected int devnumP() {return this.partidas.size();}

	/**
	 * Devuelve la informaci�n de las partidas que se est�n disputando.
	 * No es un m�todo remoto porque s�lo lo necesita el Servidor.
	 */
	protected String listaTodasPart() throws RemoteException {
		String listado = "Partidas que se est�n disputando:";
		for (Partida p : this.partidas) {listado += "\n" + p;}
		listado += "\n";
		return listado;
	}
	
}
