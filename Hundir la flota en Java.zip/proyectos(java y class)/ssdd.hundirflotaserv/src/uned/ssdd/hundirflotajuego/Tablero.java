/**
 * Autor: Carlos Alberto Pi�ero Olanda
 * Correo electr�nico: cpinero30@alumno.uned.es
 * 
 */

package uned.ssdd.hundirflotajuego;

import java.util.*;

/**
 * La clase Tablero representa dos conceptos fundamentales del juego:
 * 1- El tablero de cada jugador, donde dispone de sus dos barcos.
 * 2- El tablero de exploraci�n, que representa la informaci�n conocida del tablero del contrincante.
 * 
 */
public class Tablero {
	
	/**
	 * Tipos de casillas. El tablero de cada jugador comienza cono casillas de AGUA y de ambos barcos
	 * Evoluciona transformando la primera en FALLO y la segunda en ACIERTO
	 * Aparte, existe el tablero de exploraci�n, que empieza con todas sus casillas del tipo DESCONOCIDO
	 * Tambi�n evoluciona a FALLO y ACIERTO seg�n los mensajes que le lleguen
	 */
	private enum Casilla{DESCONOCIDO, AGUA, BARCO1, BARCO2, FALLO, ACIERTO};

	/**
	 * Los campos de la clase son:
	 * 1-Una constante que representa el alfabeto.
	 * 2-Las casillas representan el tablero.
	 * 3-Las casillas ocupadas por los dos barcos (si es un tablero de jugador). 
	 * 4-Las dimensiones del tablero.
	 * 5-Una constante que indica cu�l es el valor m�ximo de las filas.
	 * 6-El mensaje del resultado de cada jugada.
	 */
	private final String alfabeto = "ABCDEFGHIJKLMNOPQRSTUVWXY";
	private ArrayList<Casilla> casillas;
	private ArrayList<Integer> barco1, barco2;
	private int largo, alto, filaMax;
	private String mensaje;

	/**
	 * El booleano denota si va a ser un tablero de exploraci�n o no. 
	 */
	protected Tablero(int largo, int alto, boolean explorac){
		this.largo = largo;
		this.alto = alto;
		this.filaMax = this.alto - 1; 
		this.casillas = new ArrayList<Casilla>(this.largo * this.alto);
		Casilla casilla;
		if (explorac) {casilla = Casilla.DESCONOCIDO;}
		else {casilla = Casilla.AGUA;}
		for (int i = 0; i < this.largo * this.alto; i++){casillas.add(casilla);}
		this.barco1 = null;
		this.barco2 = null;
	}
	
	/**
	 * Comprueba si el formato del comando es el correcto
	 */
	private int comprComando(String comando, boolean posBarcos) {
		// Tomamos la longitud del comando
		int lonCom = comando.length();
		// Se comprueba si su longitud equivale al menos a la misma
		int lon = 2;
		if (posBarcos) {lon++;}
		if (lonCom < lon) {return -1;}
		// Primer car�cter. Si no est� en el rango de letras posibles, se rechaza
		int fila = this.alfabeto.indexOf(comando.charAt(0));
		if (fila < 0 || fila > this.filaMax) {return -1;}
		// Se pasa a decenas
		int posCas = this.alfabeto.indexOf(comando.charAt(0)) * 10;
		// Segundo car�cter. Si no est� en el rango de cifras posibles, se rechaza
		if (!Character.isDigit(comando.charAt(1))) {return -1;}
		String col = String.valueOf(comando.charAt(1));
		// Es posible que el tercer car�cter sea un n�mero.
		// En ese caso se lee como n�mero
		// Adem�s la longitud m�nima aumenta en uno
		if (lonCom > 2 && Character.isDigit(comando.charAt(2))) {
			col += String.valueOf(comando.charAt(2));
			lon++;
			// Esta comprobaci�n se hace por si es un barco
			if (lonCom < lon) {return -1;}
		}
		//Se pasa a entero
		int colN = Integer.parseInt(col);
		if (colN < 1 || colN > this.largo) {return -1;}
		// Se suma a las decenas ya calculadas
		posCas += colN - 1;
		//Si es la posici�n es un barco, es necesario comprobar que es la letra H o V
		char orien = comando.charAt(lon - 1);
		if (posBarcos && orien != 'V' && orien != 'H') {return -1;}
		return posCas;
	}

	/**
	 * Calcula las casillas que tomar�a el barco y si se salen del tablero.
	 */
	private ArrayList<Integer> ponBarco(int proa, char orien){
		ArrayList<Integer> barco = new ArrayList<Integer>(3);
		int cas2, cas3;
		if (orien == 'H') {
			cas2 = proa + 1;
			cas3 = cas2 + 1;
			if ((cas3 % this.largo) < (proa % this.largo)) {return null;}
		} else {
			cas2 = proa + this.largo;
			cas3 = cas2 + this.largo;
			if (cas3 > this.largo * this.alto - 1) {return null;}
		}
		barco.add(proa);
		barco.add(cas2);
		barco.add(cas3);
		return barco;
	}
	
	/**
	 * Comprueba si los barcos ya han sido colocados.
	 */
	protected boolean estaListo() {return this.barco1 != null && this.barco2 != null;}
	
	/**
	 * Comprueba qu� hay en la casilla atacada y cambia su contenido si es posible.
	 */
	private void comprDisparo(int posCas){
		Casilla casilla = casillas.get(posCas);
		// Hay agua, luego es un fallo
		if (casilla == Casilla.AGUA){
			this.casillas.set(posCas, Casilla.FALLO);
			this.mensaje = "F";
		// Acierta en el barco 1
		} else if (casilla == Casilla.BARCO1){
			this.casillas.set(posCas, Casilla.ACIERTO);
			this.barco1.remove(Integer.valueOf(posCas));
			this.mensaje = "A";
		// Acierta en el barco 2
		} else if (casilla == Casilla.BARCO2){
			this.casillas.set(posCas, Casilla.ACIERTO);
			this.barco2.remove(Integer.valueOf(posCas));
			this.mensaje = "A";
		// Es una casilla que ya se ha atacado 
		} else {this.mensaje = "R";}
	}
	
	/**
	 * Comprueba si los barcos ya est�n destruidos.
	 */
	protected boolean estaDerrot() {return this.barco1.isEmpty() && this.barco2.isEmpty();}
	
	/**
     * Actualiza el tablero de exploraci�n seg�n el resultado de la anterior jugada.
     */
	protected String leeJugada(String envio) {
		// Primero debe colocar los barcos.
		boolean listo = this.estaListo();
		// Se lee la casilla.
		int posCas = this.comprComando(envio, !listo);
		// Si es incorrecta, no contin�a.
		if (posCas < 0) {return "I";}
		// Si falta un barco, se coloca.
		if (!listo) {
			char orien;
			if (Character.isDigit(envio.charAt(2))) {orien = envio.charAt(3);}
			else {orien = envio.charAt(2);}
			if (this.barco1 == null) {
				this.barco1 = this.ponBarco(posCas, orien);
				if (this.barco1 == null) {return "!1";}
				for (int c : this.barco1) {this.casillas.set(c, Casilla.BARCO1);}
				return "1";
			} else {
				this.barco2 = this.ponBarco(posCas, orien);
				if (this.barco2 == null) {return "!2";}
				for (int c : this.barco2) {
					if (this.barco1.contains(c)) {
						this.barco2 = null;
						return "CB";
					}
				}
				for (int c : this.barco2) {this.casillas.set(c, Casilla.BARCO2);}
				return "2";
			}
		// En otro caso, se dispara.
		} else {this.comprDisparo(posCas);}
		// Se comprueba si ya est� derrotado.
		if (this.estaDerrot()) {this.mensaje = "V";}
		return this.mensaje;
	}
	
	/**
     * Actualiza el tablero de exploraci�n seg�n el resultado de la anterior jugada.
     */
	protected void actualTablero(String comando, boolean acierto) {
		Casilla casilla = Casilla.FALLO;
		if (acierto) {casilla = Casilla.ACIERTO;}
		this.casillas.set(this.comprComando(comando, false), casilla);
	}
	
	/**
     * Para que sea visualizado en el terminal del Jugador.
     */
	public String toString() {
		String tablero = "";
		for (int i = 1; i <= this.largo; i++) {tablero += String.format("  %2d", i);}
		for (int i = 0; i < this.largo * this.alto; i++) {
			if (i % this.largo == 0) {
				tablero += "\n" + this.alfabeto.charAt(i / this.alto);
			}
			Casilla casilla = this.casillas.get(i);
			String info = "";
			switch (casilla) {
				case AGUA:
					info = "AA";
					break;
				case BARCO1:
					info = "B1";
					break;
				case BARCO2:
					info = "B2";
					break;
				case FALLO:
					info = "FA";
					break;
				case ACIERTO:
					info = "AC";
					break;
				default:
					info = "XX";
			}
			tablero += " " + info + " ";
		}
		return tablero;
	}
}
