/**
 * Autor: Carlos Alberto Pi�ero Olanda
 * Correo electr�nico: cpinero30@alumno.uned.es
 * 
 */

package uned.ssdd.hundirflotajuego;

import java.util.ArrayList;

/**
 * Esta clase es la abstracci�n de la partida propiamente dicha.
 * Re�ne los datos de los dos jugadores, tales como sus tableros y puntuaci�n, y dictamina el ganador. 
 */
public class Partida {
	/**
	 * Los campos de la clase son:
	 * 1-Los tableros de juego y de exploracion de ambos jugadores.
	 * 2-Constantes para las dimensiones del tablero.
	 * 3-Constantes para los puntos que da alcanzar un barco y ganar la Partida. 
	 * 4-El identificador de partida.
	 * 5-La puntuaci�n de cada jugador.
	 * 6-El historial de jugadas.
	 * 7-Los nombres de los Jugadores y a qui�n le corresponde el turno.
	 * 8-El array de Strings de los mensajes.
	 * 9- Un booleano por si abandona un jugador.
	 */
	private Tablero tJug1, tJug2, tExp1, tExp2;
	private final int largo = 10, alto = 10;
	private final long punAc = 1, punVic = 4;
	private long identPart, puntos1, puntos2;
	private ArrayList<String> histJugadas;
	private String nJug1, nJug2, turnoJ;
	private String[] mensajes;
	private boolean abandono;
	
	/**
	 * El constructor inicializa los campos y adjudica un identificador de partida.
	 */
	public Partida(long identPart, String nJug1) {
		this.identPart = identPart;
		this.tExp1 = new Tablero(largo, alto, true);
		this.tExp2 = new Tablero(largo, alto, true);
		this.tJug1 = new Tablero(largo, alto, false);
		this.tJug2 = new Tablero(largo, alto, false);
		this.nJug1 = nJug1;
		this.nJug2 = null;
		this.turnoJ = this.nJug1;
		this.puntos1 = 0;
		this.puntos2 = 0;
		this.histJugadas = new ArrayList<String>();
		this.mensajes = new String[]{"", ""};
		this.abandono = false;
	}
	
	/**
	 * Comprueba si la partida ya est� iniciada, esto es, si hay un segundo Jugador.
	 */
	public boolean estaIniciada() {return this.nJug2 != null;}
	
	/**
	 * Comprueba si a la partida le corresponde el identificador.
	 */
	public boolean coincIdent(long identPart) {return this.identPart == identPart;}
	
	/**
	 * Une el segundo Jugador.
	 */
	public void uneJug(String nJug2) {this.nJug2 = nJug2;}
	
	/**
	 * Devuelve el nombre del primer Jugador.
	 */
	public String devJug1() {return nJug1;}
	
	/**
	 * Devuelve el nombre del segundo Jugador.
	 */
	public String devJug2() {return nJug2;}
	
	/**
     * Hay que colocar los barcos antes de empezar a jugar.
     * Como no importa el orden, es necesario que el mensaje incluya el identificador del jugador.
     */
	public String ponBarco(String[] recibido) {
		// Se identifica al Jugador que pone los barcos. 
		String nJug = recibido[0];
		// Se pasa la jugada a may�sculas.
		String jugada = recibido[1];
		jugada = jugada.toUpperCase();
		String resultado = "";
		// Se pasa al Jugador correspondiente.
		if (nJug.compareTo(this.nJug1) == 0) {resultado = this.tJug1.leeJugada(jugada);}
		else if (nJug.compareTo(this.nJug2) == 0) {resultado = this.tJug2.leeJugada(jugada);}
		// Se comprueba si ya est�n listos ambos Jugadores.
		if (this.tJug1.estaListo() && this.tJug2.estaListo()) {
			resultado = "Listo";
			histJugadas.add("La partida va a comenzar. El primer turno es de " + this.turnoJ);
		}
		return resultado;
	}
	
	/**
     * Procesa el turno y graba el resultado si es correcto.
     */
	private void procTurno(String jugada) {
		// Este booleano expresa si la jugada es correcta.
		boolean correcto = true;
		// Se pasa la jugada a may�sculas.
		jugada = jugada.toUpperCase();
		// Se usan variables locales para, seg�n el turno, hacer los cambios pertinentes en los campos.
		Tablero tJuego = this.tJug2;
		Tablero tExp = this.tExp1;
		String jugAct = this.nJug1;
		String jugPas = this.nJug2;
		long puntosAct = this.puntos1;;
		long puntosPas = this.puntos2;
		if (this.turnoJ.compareTo(this.nJug2) == 0){
			tJuego = this.tJug1;
			tExp = this.tExp2;
			jugAct = this.nJug2;
			jugPas = this.nJug1;
			puntosAct = this.puntos2;
			puntosPas = this.puntos1;
		}
		// Se registrar� en el historial de jugadas.
		String accion = "";
		// Si el Jugador abandona, se acaba la Partida.
		if (jugada.indexOf("CAPITULO") > -1) {
			this.abandono = true;
			this.mensajes[1] = "AB";
			accion = String.format("%s ha abandonado la partida. ", jugAct);
			// El Jugador que abandona cede todos sus puntos al contrincante.
			puntosPas += puntosAct;
			accion += String.format("%s gana la partida con %d puntos.", jugPas, puntosPas);
			if (this.turnoJ.compareTo(this.nJug1) == 0) {
				this.puntos1 = 0;
				this.puntos2 = puntosPas;
			} else {
				this.puntos2 = 0;
				this.puntos1 = puntosPas;
			}
		} else {
			this.mensajes[1] = tJuego.leeJugada(jugada);
			// Ha acertado, pero a�n no ha ganado.
			if (this.mensajes[1].compareTo("A") == 0) {
				tExp.actualTablero(jugada, true);
				puntosAct += this.punAc;
				accion = String.format("%s ha alcanzado un buque de %s. ", jugAct, jugPas);
				accion += String.format("%s tiene %d puntos. ", jugAct, puntosAct);
				accion += String.format("%s tiene un turno extra.", jugAct);
			// Ha destruido la flota enemiga.
			} else if (this.mensajes[1].compareTo("V") == 0) {
				tExp.actualTablero(jugada, true);
				puntosAct += this.punAc + this.punVic;
				accion = String.format("%s ha derrotado a %s. ", jugAct, jugPas);
				accion += String.format("%s gana la partida con %d puntos.", jugAct, puntosAct);
			// Ha dado en agua.
			} else if (this.mensajes[1].compareTo("F") == 0) {
				tExp.actualTablero(jugada, false);
				accion = String.format("%s ha fallado. Es el turno de %s", jugAct, jugPas);
				if (this.turnoJ.compareTo(this.nJug1) == 0) {this.turnoJ = this.nJug2;}
				else {this.turnoJ = this.nJug1;}
			// El comando es err�neo o repetido.
			} else {correcto = false;}
			if (this.turnoJ.compareTo(this.nJug1) == 0) {
				this.puntos1 = puntosAct;
				this.puntos2 = puntosPas;
			} else {
				this.puntos2 = puntosAct;
				this.puntos1 = puntosPas;
			}
		}
		// Se actualiza el historial de jugadas y los mensajes  si el resultado es correcto.
		this.mensajes[0] = String.valueOf(correcto);
		this.mensajes[1] = "Disparo correcto.";
		if (!correcto) {this.mensajes[1] = "Disparo incorrecto.";}
		else {this.histJugadas.add(accion);}
	}
	
	/**
	 * Procesa el turno y devuelve el resultado.
	 */
	public String[] devMensajes(String jugada) {
		this.procTurno(jugada);
		return this.mensajes;
	}
	
	/**
	 * Devuelve el estado de la partida y el tablero que le interesa al Jugador.
	 */
	public String[] devEstado(String jugador) {
		// Se toma la �ltima jugada.
		String ultAcc = this.histJugadas.get(this.histJugadas.size() - 1);
		// Se comprueba si la Partida ha acabado. 
		boolean acabada = this.abandono || this.tJug1.estaDerrot() || this.tJug2.estaDerrot();
		// Se adjunta el Tablero de juego o exploraci�n seg�n sea su turno o no.
		String tablero = "\nTu tablero de ";
		if (jugador.compareTo(this.turnoJ) == 0) {
			tablero += "exploraci�n es \n\n";
			if (jugador.compareTo(this.nJug1) == 0) {tablero += this.tExp1.toString();}
			else {tablero += this.tExp2.toString();}
		} else if (jugador.compareTo(this.nJug1) == 0) {tablero += "juego es \n\n" + this.tJug1.toString();}
		else {tablero += "juego es \n\n" + this.tJug2.toString();}
		// Se devuelve si la Partida ha acabado, de qui�n es el turno y el Tablero.
		return new String[] {String.valueOf(acabada), this.turnoJ, ultAcc, tablero};
	}
	
	/**
	 * Comprueba si el Jugador es el primero o el segundo para cuando acaba la Partida.
	 */
	public boolean esJugador1(String nombre) {return nJug1.compareTo(nombre) == 0;}
	
	/**
	 * Devuelve el resultado del final de la Partida.
	 */
	public String[] devFinal() {
		String idP = String.valueOf(this.identPart);
		String pun1 = String.valueOf(this.puntos1);
		String pun2 = String.valueOf(this.puntos2);
		// El ganador se condifica como "1" � "2".
		String ganador = "1";
		if (this.puntos2 > this.puntos1) {ganador = "2";}
		String historial = "";
		for (String j : this.histJugadas) {historial += j + "\n";}
		return new String[] {idP, this.nJug1, this.nJug2, historial, pun1, pun2, ganador};
	}
	
	/**
     * Expresa sus datos como texto para mostr�rselo al Jugador o al responsable del Servidor.
     */
	public String toString() {
		String info = "Identificador: " + this.identPart + " Jugadores: " + this.nJug1 + " contra " + this.nJug2;
		info += "\nPuntuaciones: " + this.puntos1 + " " + this.puntos2;
		if (this.estaIniciada()) {
			info += " Jugadores: " + this.nJug1 + " contra " + this.nJug2;
			info += "\nPuntuaciones: " + this.puntos1 + " " + this.puntos2;
		} else {info += " El jugador " + this.nJug1 + " est� esperando un contrincante.";}
		return info;
	}
	
}
