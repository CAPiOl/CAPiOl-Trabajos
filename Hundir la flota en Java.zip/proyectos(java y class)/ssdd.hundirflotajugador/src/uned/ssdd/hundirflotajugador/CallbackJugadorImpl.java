/**
 * Autor: Carlos Alberto Pi�ero Olanda
 * Correo electr�nico: cpinero30@alumno.uned.es
 * 
 */

package uned.ssdd.hundirflotajugador;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

import uned.ssdd.hundirflotainterfaces.CallbackJugadorInterface;

/**
 * Esta clase implementa la interfaz de CallbackJugadorInterface.
 * Se encarga de recibir los mensajes para la entidad Jugador.
 * Es una de las clases que el enunciado obliga a implementar.
 * 
 */
public class CallbackJugadorImpl extends UnicastRemoteObject implements CallbackJugadorInterface {
	/**
	 * Exigido por extender UnicastRemoteObject
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * El �nico campo necesario es una lista sincronizada.
	 */
	private ListaSincronizada listaSinc;
	
	/**
	 * El constructor inicializa los campos.
	 */
	public CallbackJugadorImpl(ListaSincronizada listaSinc) throws RemoteException {
		try {
			this.listaSinc = listaSinc;
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void recogeEvento(String mensaje) throws RemoteException {this.listaSinc.adicionarEvento(mensaje);}
}
