/**
 * Autor: Carlos Alberto Pi�ero Olanda
 * Correo electr�nico: cpinero30@alumno.uned.es
 * 
 */

package uned.ssdd.hundirflotajugador;

import java.util.ArrayList;
import java.util.List;

/**
 * Esta clase es la lista sincronizada que se nos ha recomendado implementar.
 * 
 */
public class ListaSincronizada {
	private List <String> lista;

	protected ListaSincronizada () {lista= new ArrayList<String>();}

	public synchronized int nDdatosPendientes() {return (lista.size());}

	public synchronized void adicionarEvento(String dato) {
		lista.add(dato);
		notifyAll();
	}
	public synchronized String obtenerEvento() throws InterruptedException {
		if (lista.size()==0) wait();
		String dato = lista.get(0);
		lista.remove(0);
		return dato;
	}
}
