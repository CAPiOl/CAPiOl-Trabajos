/**
 * Autor: Carlos Alberto Pi�ero Olanda
 * Correo electr�nico: cpinero30@alumno.uned.es
 * 
 */

package uned.ssdd.hundirflotajugador;

import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

import uned.ssdd.hundirflotainterfaces.*;
import uned.ssdd.hundirflotafundam.Lector;

/**
 * Esta clase contiene el m�todo main para la entidad Jugador.
 * Es una de las clases que el enunciado obliga a implementar.
 * 
 */
public class Jugador {
	/**
	 * Los campos necesarios para que el m�todo main son:
	 * 1- Los servicios remotos del Servidor.
	 * 2- Su lista sincronizada para recibir eventos.
	 * 3- Su servicio de callback. 
	 * 4- Su nombre de jugador.
	 * 5- El identificador de la partida que est� jugando.
	 */
	private static ServicioAutenticacionInterface autenStub;
	private static ServicioGestorInterface gestStub;
	private static ListaSincronizada listaSinc;
	private static CallbackJugadorInterface cbStub;
	private static String nombreJug;
	private static long identPart; 
	
	/**
	 * El constructor levanta todos los objetos remotos necesarios.
	 */
	public Jugador() {
		try {
			// Se registra el Servidor y sus servicios.
			Registry registry = LocateRegistry.getRegistry(6766);
			String nAuten = ServicioAutenticacionInterface.NOMBRE_AUTEN;
			autenStub = (ServicioAutenticacionInterface) registry.lookup(nAuten);
			String nGes = ServicioGestorInterface.NOMBRE_GESTOR;
			gestStub = (ServicioGestorInterface) registry.lookup(nGes);
			
			//Se inicializa la lista sincronizada.
			listaSinc = new ListaSincronizada();
			//Se crea el callback.
			cbStub = new CallbackJugadorImpl(listaSinc);
			cbStub = (CallbackJugadorInterface) cbStub;
			
			// Se inicializan el nombre y el identificador de partida.
			nombreJug = "";
			identPart = 0;
		} catch (Exception e) {
			System.err.println("Server exception: " + e.toString());
			e.printStackTrace();
		}
	}
	
	/**
	 * Mostrar� la interfaz del Jugador. Es la m�s compleja, ya que tiene dos partes.
	 */
	public static void main(String args[]) {
		try {
			new Jugador();
			// Cuando se inicia la aplicaci�n, aparece el men� de registro, login y salir.
			while (true) {
				System.out.println("Bienvenido a Hundir la flota.\nLas operaciones disponibles son:");
				System.out.println("1-Registro de nuevo jugador.\n2-Hacer login.\n3-Salir.");
				int opcion = Lector.leeDatosNumericos(1, 3);
				// Salir.
				if (opcion == 3) {return;}
				// Login.
				else if (opcion == 2) {if (hazLogin()) {break;};}
				// Registro.
				else {registraJug();}
			}
			// Una vez logueado, se tienen cinco opciones.
			while (true){
				System.out.printf("Te damos la bienvenida, %s.", nombreJug);
				System.out.println("\nHas abierto sesi�n en Hundir la flota.\nLas operaciones disponibles son:");
				System.out.println("1-Consulta tu informaci�n.\n2-Empezar partida.\n3-Listar partidas empezadas.");
				System.out.println("4-Unirte a una partida empezada.\n5-Salir (Logout).");
				int opcion = Lector.leeDatosNumericos(1, 5);
				switch (opcion) {
					// Solicita su informaci�n.
					case 1:
						System.out.println(gestStub.informaJug(nombreJug));
						break;
					// Inicia partida.
					case 2:
						identPart = gestStub.creaPartida(nombreJug, cbStub);//SERIALIZABLE!!!!
						System.out.println("Espera hasta que se una otro jugador.");
						juega();
						break;
					// Solicita informaci�n sobre las partidas en espera de contrincante.
					case 3:
						System.out.println(gestStub.listaPartNoInic()[1]);
						break;
					// Intenta unirse a una partida iniciada.
					case 4:
						identPart = seleccRival();
						if (identPart > -1) {juega();}
						break;
					// Salir.
					default:
						System.out.println(autenStub.hacerUnlogin(nombreJug));
						return;
				}
			}
		} catch (Exception e) {
			System.err.println("Server exception: " + e.toString());
			e.printStackTrace();
		}
	}
	
	/**
	 * Lleva a cabo el registro del jugador.
	 */
	private static void registraJug() {
		String[] mensaje = new String[] {"", ""};
		System.out.println("Necesitas nombre y password: ");
		System.out.println("Introduce un nombre: ");
		mensaje[0] = Lector.leeTexto();
		System.out.println("Introduce un password: ");
		mensaje[1] = Lector.leeTexto();
		// Se invoca el m�todo remoto que recoge el mensaje en el Servidor
		try {System.out.println(autenStub.registrar(mensaje));}
		catch (Exception e) {
			System.err.println("Server exception: " + e.toString());
			e.printStackTrace();
		}
	}
	
	/**
	 * Lleva a cabo el login del jugador.
	 */
	private static boolean hazLogin() {
		String respuesta = "";
		String[] mensaje = new String[] {"", ""};
		System.out.println("Introduce tu nombre y password: ");
		System.out.println("Introduce el nombre: ");
		mensaje[0] = Lector.leeTexto();
		System.out.println("Introduce el password: ");
		mensaje[1] = Lector.leeTexto();
		// Se invoca el m�todo remoto que recoge el mensaje en el Servidor
		// Se espera el evento de respuesta
		try {
			respuesta = autenStub.hacerLogin(mensaje);
			boolean logueado = respuesta.contains("Logueado");
			System.out.println(respuesta);
			nombreJug = mensaje[0];
			return logueado;
		} catch (Exception e) {
			System.err.println("Server exception: " + e.toString());
			e.printStackTrace();
		}
		return false;
	}
	
	/**
	 * Lleva a cabo la selecci�n de partida iniciada.  
	 */
	private static long seleccRival() {
		try {
			String[] respuesta = gestStub.listaPartNoInic();
			System.out.println(respuesta[1]);
			if (respuesta[0].compareTo("0") == 0) {
				System.out.println("No hay partidas iniciadas. Inicia una si quieres jugar.\n");
				return -1;
			}
			System.out.println("Escoge el identificador de la partida a la que quieras unirte: ");
			//Se lee el identificador. No se comprueba que est� dentro de la lista
			long identPart = Lector.leeNumNoNeg();
			//Llama al m�todo correspondiente
			String[] envio = new String[] {nombreJug, String.valueOf(identPart)};
			String[] recibo = gestStub.unirsePart(envio, cbStub);
			System.out.println(recibo[1]);
			if (recibo[0].compareTo("true") == 0) {return identPart;}
			else {return -1;}
		} catch (Exception e) {
			System.err.println("Server exception: " + e.toString());
			e.printStackTrace();
		}
		return -1;
	}
	
	/**
	 * Recoge el comando del Jugador.  
	 */
	private static String leeComando() {return Lector.leeTexto();}
	
	/**
	 * Comprueba si el primer mensaje del String es cierto.  
	 */
	private static boolean esCorrecto(String confirmacion) {return Boolean.parseBoolean(confirmacion);}
	
	/**
	 * Recoge las actividades del Jugador mientras juega.  
	 */
	private static void juega() {
		try {
			System.out.println(listaSinc.obtenerEvento());
			// Hay que poner los barcos. Esta acci�n no precisa de callback, ya que pueden ser simult�neas.
			boolean listo = false;
			while (!listo) {
				System.out.println("Introduce las coordenadas de tu primer barco [Letra-N�mero-Orientaci�n]: ");
				String posBar = leeComando();
				String[] mensajes = gestStub.leeBarcos(new String[] {String.valueOf(identPart), nombreJug, posBar});
				System.out.println(mensajes[1]);
				listo = esCorrecto(mensajes[0]);
			}
			// Ahora le toca al otro barco
			listo = false;
			while (!listo) {
				System.out.println("Introduce las coordenadas de tu segundo barco [Letra-N�mero-Orientaci�n]: ");
				String posBar = leeComando();
				String[] mensajes = gestStub.leeBarcos(new String[] {String.valueOf(identPart), nombreJug, posBar});
				System.out.println(mensajes[1]);
				listo = esCorrecto(mensajes[0]);
			}
			// A partir de ahora s� es necesario que el callback act�e, pues empieza la partida.
			while (true) {
				System.out.println(listaSinc.obtenerEvento());
				String[] estPart = gestStub.devMensajes(new String[] {String.valueOf(identPart), nombreJug});
				System.out.println(estPart[2]);
				System.out.println(estPart[3]);
				// Se comprueba que la partida siga
				if (esCorrecto(estPart[0])) {
					gestStub.acabaPartida(new String[] {String.valueOf(identPart), nombreJug});
					break;
				}
				// Si es su turno, ataca
				boolean correcto = false;
				if (nombreJug.compareTo(estPart[1]) == 0) {
					while (!correcto) {
						System.out.println("Introduce las coordenadas de tu ataque [Letra-N�mero]: ");
						String tiro = leeComando();
						String[] mensajes = gestStub.leeDisparo(new String[] {String.valueOf(identPart), nombreJug, tiro});
						// No se considera evento un tiro fallido o repetido, por lo que se repite si ha fallado
						correcto = esCorrecto(mensajes[0]);
					}
				}
			}
			
		} catch (Exception e) {
			System.err.println("Ha fallado algo: " + e.toString());
			e.printStackTrace();
		}
	}
}
