/**
 * Autor: Carlos Alberto Pi�ero Olanda
 * Correo electr�nico: cpinero30@alumno.uned.es
 * 
 */

package uned.ssdd.hundirflotadatos;

/**
 * La clase DatosJugador representa los datos asociados a un jugador registrado.
 * 
 */
public class DatosJugador {
	
	/**
	 * Los campos de la clase son:
	 * 1-Su nombre y password. El primero debe ser �nico para cada jugador.
	 * 2-Su puntuaci�n total.
	 * 3-N�mero de partidas disputadas, m�s el de victorias y derrotas.
	 */
	private String nombre, pw;
	private long puntos, partidas, victorias, derrotas;
	
	/**
	 * El constructor inicializa los campos y registra nombre y contrase�a.
	 */
	public DatosJugador(String[] nombrePW) {
		this.nombre = nombrePW[0];
		this.pw = nombrePW[1];
		this.puntos = 0;
		this.partidas = 0;
		this.victorias = 0;
		this.derrotas = 0;
	}
	
	/**
	 * Comprueba si coincide el nombre con el pasado como argumento.
	 */
	public int coincideNombre(String nombre) {return this.nombre.compareTo(nombre);}
	
	/**
	 * Comprueba si coincide el password con el pasado como argumento.
	 */
	public boolean coincidePW(String pw) {return this.pw.compareTo(pw) == 0;}
	
	/**
	 * Actualiza los datos del Jugador despu�s de acabar una Partida.
	 */
	public void actualDatos(long puntos, boolean victoria) {
		this.puntos += puntos;
		this.partidas++;
		if (victoria) {this.victorias++;} else {this.derrotas++;} 
	}
	
	/**
	 * Para cuando se solicite informaci�n.
	 */
	public String toString() {
		String datos = "\nNombre: " + this.nombre + " Partidas: " + this.partidas + " Victorias: ";
		return datos + this.victorias + " Derrotas: " + this.derrotas + " Puntuaci�n: " + this.puntos;
	}
}
