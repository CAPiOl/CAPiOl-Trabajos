/**
 * Autor: Carlos Alberto Pi�ero Olanda
 * Correo electr�nico: cpinero30@alumno.uned.es
 * 
 */

package uned.ssdd.hundirflotadatos;

import java.util.*;

/**
 * Esta clase representa los datos de una partida ya acabada.
 * 
 */
public class DatosPartida {
	/**
	 * Los campos de la clase son:
	 * 1-El identificador de la Partida.
	 * 2-Los identificadores de cada Jugador.
	 * 3-Los cuatro Tableros, dos por cada Jugador. 
	 * 4-El historial de disparos de ambos Jugadores.
	 * 5-Un booleano. Si es cierto, gan� el Jugador 1; si falso, el 2.
	 */
	private long identPart;
	private String nJug1, nJug2, historial, puntos1, puntos2;
	private int ganador;
	private boolean gano1, capitulacion;
	
	public DatosPartida(String datos[]) {
		this.identPart = Long.parseLong(datos[0]);
		this.nJug1 = datos[1];
		this.nJug2 = datos[2];
		this.historial = datos[3];
		this.puntos1 = datos[4];
		this.puntos2 = datos[5];
		this.ganador = Integer.parseInt(datos[6]);
	}
	
	
}
