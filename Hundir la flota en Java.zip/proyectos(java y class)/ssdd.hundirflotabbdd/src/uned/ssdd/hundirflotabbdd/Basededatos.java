/**
 * Autor: Carlos Alberto Piñero Olanda
 * Correo electrónico: cpinero30@alumno.uned.es
 * 
 */

package uned.ssdd.hundirflotabbdd;

import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.time.LocalDateTime;
import java.util.Arrays;

import uned.ssdd.hundirflotainterfaces.ServicioDatosInterface;
import uned.ssdd.hundirflotafundam.Lector;

/**
 * Esta clase contiene el método main para la entidad Base de Datos.
 * Es una de las clases que el enunciado obliga a implementar.
 * 
 */
public class Basededatos {
	/**
	 * El único campo necesario para el método main es el servicio de datos.
	 * Aparte, vamos a registrar la fecha y hora en que se levanta la Base de Datos.
	 * Se mostrará en la operación de mostrar información sobre este. 
	 */
	//private static ServicioGestorInterface servGesStub;
	private static ServicioDatosImpl servDat;
	private static LocalDateTime fecha;
	
	/**
	 * El constructor va a levantar la Base de Datos.
	 */
	public Basededatos() {
		try {
			//Se registra la fecha de creación.
			fecha = LocalDateTime.now();
			
			Registry registry = LocateRegistry.createRegistry(8833);
			servDat = new ServicioDatosImpl();
			int puertoD = ServicioDatosInterface.portDatos;
			ServicioDatosInterface servDatStub = (ServicioDatosInterface) UnicastRemoteObject.exportObject(servDat, puertoD);
			
			registry.rebind(ServicioDatosInterface.NOMBRE_DATOS, servDatStub);
			
			System.out.println(Arrays.toString(registry.list()));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Mostrará la interfaz de la Base de Datos. Esta es sencilla y sólo comprende dos operaciones más salir.
	 */
	public static void main(String[] args) {
		try {
			new Basededatos();  
			while (true){
				System.out.println("Base de datos operativa\nLas operaciones disponibles son:");
				System.out.println("1-Información del Servidor.\n2-Listar jugadores registrados.\n3-Salir.");
				int opcion = Lector.leeDatosNumericos(1, 3);
				if (opcion == 3) {break;}
				else if (opcion == 2) {servDat.listaJugadores();}
				else {informaBDD();}
			}
			System.out.println("Base de datos finalizada.");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Muestra la información de la Base de Datos:
	 * Su fecha y hora de creación, cuántos usuarios hay registraos y cuántas partidas hay guardadas.
	 */
	private static void informaBDD() {
		System.out.println("\nEsta es la base de datos del servidor de Hundir la flota on-line.");
		System.out.println("Fue creada por Carlos Alberto Piñero Olanda.");
		String textFecha = String.valueOf(fecha);
		String dia = textFecha.substring(0, 10);
		String hora = textFecha.substring(11, 19);
		System.out.printf("Se levantó el día en la fecha %s a la hora %s.", dia, hora);
		int nReg = servDat.devRegist();
		int nPar = servDat.devNumP();
		System.out.printf("\nAhora mismo hay %d usuarios registrados y se han disputado %d partidas.\n\n", nReg, nPar);
	}
	
		
}
