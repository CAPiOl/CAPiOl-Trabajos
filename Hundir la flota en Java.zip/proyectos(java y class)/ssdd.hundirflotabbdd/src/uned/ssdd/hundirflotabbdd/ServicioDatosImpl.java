/**
 * Autor: Carlos Alberto Pi�ero Olanda
 * Correo electr�nico: cpinero30@alumno.uned.es
 * 
 */

package uned.ssdd.hundirflotabbdd;

import java.rmi.RemoteException;
import java.util.ArrayList;

import uned.ssdd.hundirflotainterfaces.ServicioDatosInterface;
import uned.ssdd.hundirflotadatos.*;

/**
 * Esta clase implementa la interfaz de ServicioDatosInterface.
 * Se encarga de efectuar las operaciones de la Base de Datos.
 * Es una de las clases que el enunciado obliga a implementar.
 * 
 */
public class ServicioDatosImpl implements ServicioDatosInterface {
	/**
	 * Los campos necesarios son los jugadores y las partidas disputadas.
	 */
	private ArrayList<DatosJugador> jugadores;
	private ArrayList<DatosPartida> datosPart;
	
	/**
	 * El constructor inicializa los campos.
	 */
	public ServicioDatosImpl() {
		this.jugadores = new ArrayList<DatosJugador>();
		this.datosPart = new ArrayList<DatosPartida>();
	}
	
	@Override
	public String registraJug(String[] nuevoJugador) throws RemoteException {
		String nuevoJug = nuevoJugador[0];
		int pJug = 0;
		for (DatosJugador jug : this.jugadores) {
			if (jug.coincideNombre(nuevoJug) == 0) {return "Ya existe un jugador con ese nombre. Usa otro distinto.";}
			else if (jug.coincideNombre(nuevoJug) > 0) {break;}
			else {pJug++;}
		}
		DatosJugador nuevJug = new DatosJugador(nuevoJugador);
		this.jugadores.add(pJug, nuevJug);
		String respuesta = "�Enhorabuena! Ya est�s registrado como "  + nuevoJug;
		return respuesta + ".\nHaz login con tu nombre y tu password para jugar.";
	}

	@Override
	public String existeJugador(String[] jugador) throws RemoteException {
		String posibleJug = jugador[0];
		DatosJugador jug = this.encuentraJug(posibleJug);
		if (jug == null) {return "No existe ese Jugador en la Base de Datos.";}
		else if (jug.coincidePW(jugador[1])) {return "Logueado.";}
		return "Password incorrecto.";
	}

	@Override
	public String informaJug(String nombre) throws RemoteException {
		DatosJugador jug = this.encuentraJug(nombre);
		return "Estos son tus datos: " + jug + "\n";
	}

	@Override
	public void actualDatos(String[] datos) throws RemoteException {
		this.datosPart.add(new DatosPartida(datos));
		DatosJugador jug1 = this.encuentraJug(datos[1]);
		DatosJugador jug2 = this.encuentraJug(datos[2]);
		boolean gano1 = Integer.parseInt(datos[6]) == 1;
		jug1.actualDatos(Long.parseLong(datos[4]), gano1);
		jug2.actualDatos(Long.parseLong(datos[5]), !gano1);
	}
	
	/**
	 * Busca el jugador seg�n su nombre.
	 */
	private DatosJugador encuentraJug(String nombre) {
		for (DatosJugador jug : this.jugadores) {if (jug.coincideNombre(nombre) == 0) {return jug;}}
		return null;
	}
	
	/**
	 * Devuelve el n�mero de jugadores registrados.
	 * No es un m�todo remoto porque s�lo lo necesita la Base de Datos.
	 */
	protected int devRegist() {return this.jugadores.size();}
	
	/**
	 * Devuelve el n�mero de partidas disputadas.
	 * No es un m�todo remoto porque s�lo lo necesita la Base de Datos.
	 */
	protected int devNumP() {return this.datosPart.size();}
	
	protected void listaJugadores() throws RemoteException {
		String listado = "Datos de los jugadores registrados:";
		for (DatosJugador jug : this.jugadores) {listado += "\n" + jug;}
		listado += "\n";
		System.out.println(listado);
	}
}
