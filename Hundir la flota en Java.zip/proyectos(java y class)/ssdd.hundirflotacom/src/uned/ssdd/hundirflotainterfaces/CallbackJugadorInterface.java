/**
 * Autor: Carlos Alberto Pi�ero Olanda
 * Correo electr�nico: cpinero30@alumno.uned.es
 * 
 */

package uned.ssdd.hundirflotainterfaces;

import java.rmi.Remote;
import java.rmi.RemoteException;

/**
 * Esta interfaz representa la cara visible del receptor de mensajes del servidor para el jugador.
 * Es una de las interfaces que el enunciado obliga a implementar.
 * 
 */
public interface CallbackJugadorInterface extends Remote {
	/**
	 * Campos necesarios para establecer la conexi�n remota.
	 */
	public static final String NOMBRE_CALLBACK = "Callback";
	public static final String host = "hostCallback";
	public int portCallback = 5064;
	
	/**
	 * Escribe en la lista sincronizada un evento.
	 */
	public void recogeEvento(String mensaje) throws RemoteException;
}
