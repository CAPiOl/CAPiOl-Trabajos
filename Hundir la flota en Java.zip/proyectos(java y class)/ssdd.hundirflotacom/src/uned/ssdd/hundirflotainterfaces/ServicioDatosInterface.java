/**
 * Autor: Carlos Alberto Pi�ero Olanda
 * Correo electr�nico: cpinero30@alumno.uned.es
 * 
 */

package uned.ssdd.hundirflotainterfaces;

import java.rmi.Remote;
import java.rmi.RemoteException;

/**
 * Esta interfaz representa la cara visible del servicio de la entidad Base de Datos.
 * Es una de las interfaces que el enunciado obliga a implementar.
 * 
 */
public interface ServicioDatosInterface extends Remote{
	/**
	 * Campos necesarios para establecer la conexi�n remota.
	 */
	public static final String NOMBRE_DATOS = "ServicioDatos";
	public static final String host = "hostBBDD";
	public static final int portDatos = 8834;
	
	/**
	 * Intenta registrar un jugador y devuelve la confirmaci�n si el nombre es nuevo. 
	 */
	public String registraJug(String[] nuevoJugador) throws RemoteException;
	/**
	 * Comprueba si un jugador est� registrado.
	 */
	public String existeJugador(String[] jugador) throws RemoteException;
	
	/**
	 * Devuelve los datos de un jugador seg�n su nombre.
	 */
	public String informaJug(String nombre) throws RemoteException;
	/**
	 * Actualiza los datos de jugadores y a�ade la partida a las existentes.
	 */
	public void actualDatos(String[] datos) throws RemoteException;
}
