/**
 * Autor: Carlos Alberto Pi�ero Olanda
 * Correo electr�nico: cpinero30@alumno.uned.es
 * 
 */

package uned.ssdd.hundirflotainterfaces;

import java.rmi.Remote;
import java.rmi.RemoteException;

/**
 * Esta interfaz representa la cara visible del gestor de partidas.
 * Es una de las interfaces que el enunciado obliga a implementar.
 * 
 */
public interface ServicioGestorInterface extends Remote {
	/**
	 * Campos necesarios para establecer la conexi�n remota.
	 */
	public static final String NOMBRE_GESTOR = "ServicioGestor";
	public static final String host = "hostGestor";
	public static final int portGestor = 6768;
	
	/**
	 * Invoca el m�todo de devolver datos de un jugador de la interfaz del servicio de la Base de Datos. 
	 */
	public String informaJug(String nombre) throws RemoteException;
	/**
	 * Crea la partida con el nombre del jugador solicitante, que ser� el primero. 
	 */
	public long creaPartida(String nJug1, CallbackJugadorInterface callback) throws RemoteException;
	/**
	 * Lista las partidas en espera de un contrincante. 
	 */
	public String[] listaPartNoInic() throws RemoteException;
	/**
	 * Une el jugador a una partida ya existente.
	 */
	public String[] unirsePart(String[] mensaje, CallbackJugadorInterface callback) throws RemoteException;
	/**
	 * Lee las coordenadas del barco y comprueba si son correctas.
	 */
	public String[] leeBarcos(String[] jugada) throws RemoteException;
	/**
	 * Lee las coordenadas del disparo y comprueba si son correctas.
	 */
	public String[] leeDisparo(String[] jugada) throws RemoteException;
	/**
	 * Devuelve a los jugadores el estado de su partida.
	 */
	public String[] devMensajes(String[] datos) throws RemoteException;
	/**
	 * Elimina los callbacks de lso jugadores cuando la partida ya ha acabado.
	 */
	public void acabaPartida(String[] datos) throws RemoteException;
}
