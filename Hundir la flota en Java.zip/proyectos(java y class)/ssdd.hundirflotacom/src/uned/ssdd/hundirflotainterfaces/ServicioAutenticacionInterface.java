/**
 * Autor: Carlos Alberto Pi�ero Olanda
 * Correo electr�nico: cpinero30@alumno.uned.es
 * 
 */

package uned.ssdd.hundirflotainterfaces;

import java.rmi.Remote;
import java.rmi.RemoteException;

/**
 * Esta interfaz representa la cara visible del gestor de jugadores.
 * Es una de las interfaces que el enunciado obliga a implementar.
 * 
 */
public interface ServicioAutenticacionInterface extends Remote{
	/**
	 * Campos necesarios para establecer la conexi�n remota.
	 */
	public static final String NOMBRE_AUTEN = "ServicioAutenticador";
	public static final String host = "hostAutenticador";
	public static final int portAuten = 6767;
	
	/**
	 * Invoca el m�todo de registrar de la interfaz del servicio de la Base de Datos. 
	 */
	public String registrar(String[] nombrePW) throws RemoteException;
	/**
	 * Le pregunta a la Base de Datos si existe el jugador. En ese caso, comprueba si ya tiene una sesi�n abierta.
	 * Si no, lo loguea. 
	 */
	public String hacerLogin(String[] nombrePW) throws RemoteException;
	/**
	 * Elimina al jugador de los jugadores logueados. 
	 */
	public String hacerUnlogin(String nombre) throws RemoteException;
}
