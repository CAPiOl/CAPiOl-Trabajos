/**
 * Autor: Carlos Alberto Pi�ero Olanda
 * Correo electr�nico: cpinero30@alumno.uned.es
 * 
 */

package uned.ssdd.hundirflotafundam;

import java.util.Scanner;

/**
 * Esta clase va a encargarse de recoger el texto introducido mediante el teclado.
 */
public class Lector {
	
	/**
	 * Lee texto.
	 */
	public static String leeTexto()
	{
		String texto = "";
		while (texto.compareTo("") == 0) {
			try {
				Scanner s = new Scanner(System.in);
				texto = s.nextLine();
			} catch (Exception e){
				System.out.println("    Ha ocurrido un error.");
			}
			if (texto.compareTo("") == 0) {System.out.println("    Debes escribir texto.");}
		}
		return texto;
	}
	
	/**
     * Lee datos num�ricos entre el rango indicado.
     */
	public static int leeDatosNumericos(int limiteInferior, int limiteSuperior)
    {
        boolean dentroRango = false;
        int num = limiteInferior - 1;
        while (!dentroRango)
        {
            try {
                Scanner s = new Scanner(System.in);
                num = s.nextInt();
            } catch (Exception e){
                System.out.println("    Ha ocurrido un error.");
            }
            
            if (num >= limiteInferior && num <= limiteSuperior){
                dentroRango = true;
            } else {
                System.out.println("    Fuera de rango.\n");
            }
        }
        return num;
    }
	
	/**
     * Lee un n�mero no negativo.
     */
	public static int leeNumNoNeg()
    {
        boolean mayor_1 = false;
        int num = -1;
        while (!mayor_1)
        {
            try {
                Scanner s = new Scanner(System.in);
                num = s.nextInt();
            } catch (Exception e){
                System.out.println("    Ha ocurrido un error.");
            }
            
            if (num >= 0){
            	mayor_1 = true;
            } else {
                System.out.println("    Debe ser un n�mero no negativo.\n");
            }
        }
        return num;
    }
}
