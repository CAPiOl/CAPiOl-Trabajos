Este archivo comprimido contiene el trabajo de Carlos Alberto Piñero Olanda, alumno del Centro Asociado de Sevilla.
Los cuatro primeros apartados deberían funcionar en cualquier carpeta porque en el Notebook se han definido las rutas relativamente.
Para el MapReducer se precisa que esta carpeta esté en /home/cloudera.
Hemos alterado el archivo de las tasas para lograr que sea legible. EXplicamos en el notebook cómo.
Mi correo electrónico es:
cpinero30@alumno.uned.es
