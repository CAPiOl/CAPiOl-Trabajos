#!/usr/bin/env python
# -*- coding: latin-1 -*-

import sys
import csv

# Mapper debe leer el fichero de partida y devolverlo con este formato:
# Nombre-AAAA-Tasa

# Recorremos la tabla
archivo = open('/home/cloudera/Sevilla-PineroOlandaCarlosAlberto/Ficheros/API_SE.PRM.CMPT.FE.ZS_DS2_es_csv_v2_5641106.csv', 'r')


tabla = csv.reader(archivo)

for line in tabla:
    # Descartamos las filas nulas
    if len(line) > 0:
        # Descartamos las filas sin nombre
        if len(line[0]) > 0:
            # Examinamos cada columna
            for i in range(3, 67):
                if len(line) < i + 1: continue
                # Descartamos las celdas sin nombre
                if line[i] != '':
                    anual = 1957 + i
                    print '%s\t%s\t%s' % (line[0], anual, line[i])