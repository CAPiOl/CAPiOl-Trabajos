#!/usr/bin/env python
# -*- coding: latin-1 -*-

import sys

#Reducer tiene dos argumentos: nombre del pais y anno
#Encontrará la linea que coincida con ambos

for line in sys.stdin:
    line = line.strip()
    pais, anual, tasa = line.split('\t')
    if pais == sys.argv[1] and anual == sys.argv[2]:
        print(tasa)